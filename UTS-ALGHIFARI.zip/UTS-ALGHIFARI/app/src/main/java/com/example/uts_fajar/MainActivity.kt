package com.example.uts_fajar

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    companion object{
        val INTENT_PARCELABLE = "OBJECT_INTENT"
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val foodList = listOf<Food>(
            Food(
                R.drawable.menu1,
                namefood =  "Rendang",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu2,
                namefood =  "Sate ayam",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu3,
                namefood =  "Nasi Goreng",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu4,
                namefood =  "Mie Goreng",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu5,
                namefood =  "Batagor",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu6,
                namefood =  "Soto",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu7,
                namefood =  "Ayam Bakar",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu8,
                namefood =  "Ayam Geprek",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu9,
                namefood =  "Nasi Padang",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu10,
                namefood =  "lalapan Ayam",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu12,
                namefood =  "Bakso",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu13,
                namefood =  "Mie Ayam",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu14,
                namefood =  "Nasi Kuning",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            ),
            Food(
                R.drawable.menu15,
                namefood =  "Nasi Pecel",
                descfood = "Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum"
            )
        )
         val recyclerView = findViewById<RecyclerView>(R.id.rv_food)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.setHasFixedSize(true)
        recyclerView.adapter = FoodAdapter(this,foodList){
            val intent = Intent (this, DetailFoodActivity::class.java)
            intent.putExtra(INTENT_PARCELABLE, it)
            startActivity(intent)
        }
    }
}