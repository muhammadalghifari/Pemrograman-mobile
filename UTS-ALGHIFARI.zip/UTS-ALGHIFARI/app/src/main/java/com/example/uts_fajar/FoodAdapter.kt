package com.example.uts_fajar

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class FoodAdapter (private val context: Context, private val food: List<Food>, val listener: (Food) -> Unit)
    : RecyclerView.Adapter<FoodAdapter.FoodViewHolder>(){
    class FoodViewHolder(view: View): RecyclerView.ViewHolder(view) {

        val imgfood = view.findViewById<ImageView>(R.id.img_item_photo)
        val namefood = view.findViewById<TextView>(R.id.tv_item_name)
        val descfood = view.findViewById<TextView>(R.id.tv_item_description)

        fun bindView(food : Food, listener: (Food) -> Unit){
            imgfood.setImageResource(food.imgfood)
            namefood.text = food.namefood
            descfood.text = food.descfood
            itemView.setOnClickListener{
                (listener(food))
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        return FoodViewHolder(
            LayoutInflater.from(context).inflate(R.layout.item_food, parent, false)
        )
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bindView(food[position], listener)
    }

    override fun getItemCount(): Int = food.size

}
