package com.example.uts_fajar

import android.os.Parcelable
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Food (
    val imgfood: Int,
    val namefood: String,
    val descfood: String
) : Parcelable