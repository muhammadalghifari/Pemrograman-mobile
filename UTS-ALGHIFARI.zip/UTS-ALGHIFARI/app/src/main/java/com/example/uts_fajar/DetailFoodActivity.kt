package com.example.uts_fajar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView

class DetailFoodActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_food)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val food = intent.getParcelableExtra<Food>(MainActivity.INTENT_PARCELABLE)

        val imgfood = findViewById<ImageView>(R.id.img_item_photo)
        val namefood = findViewById<TextView>(R.id.tv_item_name)
        val descfood = findViewById<TextView>(R.id.tv_item_description)

        imgfood.setImageResource(food?.imgfood!!)
        namefood.text = food.namefood
        descfood.text = food.descfood

    }

    override fun onSupportNavigateUp(): Boolean {

        onBackPressed()
        return true
    }
}